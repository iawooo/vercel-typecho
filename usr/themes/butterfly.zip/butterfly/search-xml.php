<?php
// 搜索数据生成脚本
header("Location: create-search-xml.php");
exit;
?>
